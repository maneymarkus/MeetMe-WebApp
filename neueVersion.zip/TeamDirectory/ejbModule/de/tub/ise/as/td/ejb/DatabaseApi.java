package de.tub.ise.as.td.ejb;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import de.tub.ise.as.td.entity.Post;
import de.tub.ise.as.td.entity.User;

@Stateless
public class DatabaseApi {
	
	@PersistenceContext
	EntityManager em;
	
	@EJB
	UserInit userInit;
	
	public List<User> getUsers() {
		TypedQuery<User> query = em.createQuery("SELECT u FROM User u", User.class);
		return query.getResultList();
	}
	
	public User getUser(int id) {
		TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.id=" + id, User.class);
		return query.getResultList().get(0);
	}
	
	public List<Post> getPosts() {
		TypedQuery<Post> query = em.createQuery("SELECT p FROM Post p", Post.class);
		List<Post> posts = query.getResultList();
		return posts;
	}
	
	public List<Post> getPosts(int destId) {
		TypedQuery<Post> query = em.createQuery("SELECT p FROM Post p WHERE p.destinationID=" + destId, Post.class);
		return query.getResultList();
	}
	
	public String setPosting(String author, int targetId, String content) {
		long timeStamp = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		Date resultDate = new Date(timeStamp);
		String myDate = sdf.format(resultDate);
		Post post = new Post(targetId, content, author, timeStamp, myDate);
		em.persist(post);
		//System.out.println(timeStamp);
		return myDate;
	}
	
}
