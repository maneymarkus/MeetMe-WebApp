var Module = (function(window, document, undefined) {

    function init() {

        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0];

        var windowWidth = w.innerWidth || e.clientWidth || g.clientWidth;
        
        var usersUrl = "http://localhost:8080/TeamDirectoryWeb/api/user/users";

        var friends = document.getElementsByClassName("friends")[0];
        var friendsButton = document.getElementsByClassName("show-friends")[0];
        var friendsClose = document.getElementsByClassName("close")[0];
        var friendsWrapper = document.getElementsByClassName("friends-wrapper")[0];
        var friendContainers = document.getElementsByClassName("friend-container");

        var friendContainersCoords = new Array();

        friendsButton.addEventListener("click", showFriends);
        friendsClose.addEventListener("click", showFriends);
        friendsWrapper.addEventListener("click", showUser);

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            	displayUsers(this.responseText);
            }
        }
        xhttp.open("GET", usersUrl, true);
        xhttp.send();
               
        function displayUsers(response) {
        	jsonResponse = JSON.parse(response);
        	var counter = 1;
        	if (jsonResponse == "") {
        		document.getElementsByClassName("fallback")[0];
        		return;
        	}
        	for (var key in jsonResponse) {
        		userObject = jsonResponse[key];
        		var friendContainer = document.createElement("div");
        		friendContainer.classList.add("friend-container", "friend-" + counter);
        		var linkUser = document.createElement("a");
        		linkUser.setAttribute("href", "./user.html");
        		var imageUser = document.createElement("img");
        		imageUser.setAttribute("src", userObject.imagePath);
        		imageUser.setAttribute("alt", "Here comes text to display when image can't be displayed.");
        		var nameSpan = document.createElement("span");
        		nameSpan.classList.add("name");
        		nameSpan.innerHTML = userObject.name;
        		var ageSpan = document.createElement("span");
        		ageSpan.classList.add("age");
        		ageSpan.innerHTML = userObject.age;
        		var idSpan = document.createElement("span");
        		idSpan.classList.add("user-id");
        		idSpan.style.display = "none";
        		idSpan.innerHTML = userObject.id;
        		linkUser.appendChild(imageUser);
        		linkUser.appendChild(nameSpan);
        		linkUser.appendChild(ageSpan);
        		linkUser.appendChild(idSpan);
        		friendContainer.appendChild(linkUser);
        		friendsWrapper.appendChild(friendContainer);
        		counter++;
        	}
        	friendsButton.removeAttribute("disabled");
        }
        
        function getFriendContainersCoords() {
            for (i = 0; i < friendContainers.length; i++) {
                var friendRect = friendContainers[i].getBoundingClientRect();
                var yCoords = Math.round(friendRect.top + (friendContainers[i].offsetHeight / 2));
                var xCoords = Math.round(friendRect.left + (friendContainers[i].offsetWidth / 2));
                var coords = {
                    xCoords : xCoords,
                    yCoords : yCoords
                }
                friendContainersCoords[i] = coords;
                //console.log(coords);
            }
        }
        
        var xCoords, yCoords, distance = null;
        function markFriend(e) {
            var e = e || window.event;
            xCoords = e.clientX;
            yCoords = e.clientY;
            for (i = 0; i < friendContainers.length; i++) {
                distance = Math.floor(Math.sqrt((Math.pow((xCoords - friendContainersCoords[i].xCoords), 2) + Math.pow((yCoords - friendContainersCoords[i].yCoords), 2))));
                if (distance < 300 && distance > 50) {
                    distance = 10 / distance;
                    friendContainers[i].style.transform = "scale(" + (1 + distance) + ", " + (1 + distance) + ")";
                    //console.log(distance);
                }
            }
        }

        function showFriends() {
            friends.classList.toggle("showing-friends");
            windowWidth = w.innerWidth || e.clientWidth || g.clientWidth;
            if (windowWidth > 960) {
                if (friends.classList.contains("showing-friends")) {
                    getFriendContainersCoords();
                    document.addEventListener("mousemove", markFriend);
                } else {
                    document.removeEventListener("mousemove", markFriend, false);
                }
            }
        }

        function showUser(e) {
            if (sessionStorage.getItem("userId") != null || sessionStorage.getItem("userId") != "") {
                sessionStorage.removeItem("userId");
            }
            var e = e || window.event;
            var target = e.target || window.target;
            while (!target.classList.contains("friend-container") || target.classList.contains("friends-wrapper")) {
                target = target.parentNode;
            }
            if (target.classList.contains("friends-wrapper")) {
                return;
            }
            var userId = target.getElementsByClassName("user-id")[0].innerHTML;
            sessionStorage.setItem("userId", userId);
        }

    }

    if (document.readyState == "loading") {
        document.addEventListener("DOMContentLoaded", function() {
            init();
        });
    } else {
        init();
    }


})(window, document)