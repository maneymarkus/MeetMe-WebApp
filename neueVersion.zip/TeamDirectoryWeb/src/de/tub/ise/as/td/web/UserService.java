package de.tub.ise.as.td.web;

import java.util.ArrayList;

import java.util.List;

import javax.ejb.EJB;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.sun.corba.se.impl.orbutil.ObjectWriter;

import de.tub.ise.as.td.ejb.DatabaseApi;
import de.tub.ise.as.td.entity.Post;
import de.tub.ise.as.td.entity.User;

@Path("/user")
public class UserService {
   
    @EJB
    private DatabaseApi databaseMgmt;

    public UserService() {
    }

    /**
     * Retrieves representation of an instance of User
     * @return an JSON as a string.
     */
    /*
    @GET
    @Produces("application/json")
    public String getUsersAsJson() {
    	
        //List<User> users = userMgmt.getUsers();
        
        Jsonb jsonb = JsonbBuilder.create();
    	
        return jsonb.toJson("hallo");
    }
    */
    
    @GET 
    @Path("/users")
    @Produces("application/json")
    public String getUsers() { 
    	List<User> users = databaseMgmt.getUsers();
    	Jsonb jsonb = JsonbBuilder.create();
    	return jsonb.toJson(users);
    }

    @GET
    @Produces("application/json")
    public String getUser(@QueryParam("userId") String userId) {
    	User user = databaseMgmt.getUser(Integer.parseInt(userId));
    	String jsonResp = "{"
    			+ "\"name\":\"" + user.getName() + "\","
    			+ "\"age\":\"" + user.getAge() + "\","
    			+ "\"starsign\":\"" + user.getStarsign() + "\","
    			+ "\"course\":\"" + user.getCourse() + "\","
    			+ "\"imagePath\":\"" + user.getImagePath() + "\","
    			+ "\"postings\":[";
    	try {
    		List<Post> postList = databaseMgmt.getPosts(Integer.parseInt(userId));
        	int counter = 0;
    		for (Post post : postList) {
    			if (counter == 0) {
    				jsonResp += "{";
    				counter++;
    			} else {
    				jsonResp += ",{";
    			}
        			jsonResp += "\"author\":\"" + post.getAuthor() + "\","
        				+ "\"date\":\"" + post.getMyDate() + "\","
        				+ "\"content\":\"" + post.getContent() + "\""
        				+ "}";
        	}
    	} catch (NullPointerException e) {
    		
    	}
    	jsonResp += "]}";
    	System.out.println(jsonResp);
    	return jsonResp;
    }
    
    @POST
    @Produces("application/json")
    public String savePost(String request) {
    	String[] params = request.split("&");
    	String author = params[0].replace("author=", "");
    	String targetId = params[1].replace("targetId=", "");
    	String content = params[2].replace("content=", "");
    	//System.out.println(author + ", " + targetId + ", " + content);
    	String response = databaseMgmt.setPosting(author, Integer.parseInt(targetId), content);
    	//System.out.println(response);
    	Jsonb jsonb = JsonbBuilder.create();
    	return jsonb.toJson(response);
    }

}